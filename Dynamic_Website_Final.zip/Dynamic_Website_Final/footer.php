<div class="content">
            <div id="footer" class="cf">
                <div class="column three">
                    <strong>Other Games:</strong>
                    <ul>
                        <li><a href="https://nightschoolstudio.com/oxenfree-ii/">OXENFREE II</a></li>
                        <li><a href="https://nightschoolstudio.com/afterparty/">Afterparty</a></li>
                        <li><a href="https://nightschoolstudio.com/next-stop-nowhere/">Next Stop Nowhere</a></li>
                        <li><a href="https://nightschoolstudio.com/mr-robot/">Mr. Robot</a></li>
                    </ul>
                </div>
                <div class="column three middle">
                <strong>Social Media:</strong>
                    <em>Follow us to stay updated!</em>
                    <br><br>
                    <a style="text-decoration:none;font-size:25px" href="https://www.facebook.com/nightschoolstudio" class="fa fa-facebook" ></a>
                    <a style="text-decoration:none;font-size:25px" href="https://twitter.com/nightschoolers" class="fa fa-twitter"></a>
                    <a style="text-decoration:none;font-size:25px" href="https://www.youtube.com/c/NightSchoolStudio" class="fa fa-youtube"></a>
                    <a style="text-decoration:none;font-size:25px" href="https://www.instagram.com/nightschoolstudio/" class="fa fa-instagram"></a>
                </div>
                <div class="columnthreelast">
                <strong>Developer:</strong>
                    Based in Los Angeles, California <br><br><br>
                    <strong>Founding Date:</strong>
                    October 1, 2014
                </div>
            </div>
            <small>&copy;<?php echo date('Y'); ?> - <?php echo $companyName; ?></small>
        </div>
    </div>
</body>
</html>